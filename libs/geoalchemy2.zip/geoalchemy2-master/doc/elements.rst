.. _elements:

Elements
========

.. autoclass:: geoalchemy2.elements.WKTElement
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: geoalchemy2.elements.WKBElement
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: geoalchemy2.elements.RasterElement
   :members:
   :show-inheritance:
