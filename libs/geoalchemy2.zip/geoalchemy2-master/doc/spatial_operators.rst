.. _spatial_operators:

Spatial Operators
=================

.. automodule:: geoalchemy2.comparator
   :members:
   :special-members:
   :show-inheritance:
