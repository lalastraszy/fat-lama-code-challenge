.. _shape:

Shapely Integration
===================

.. automodule:: geoalchemy2.shape
   :members:
   :private-members:
   :undoc-members:
   :show-inheritance:
